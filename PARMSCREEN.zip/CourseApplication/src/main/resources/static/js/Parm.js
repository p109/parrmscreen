$(document).ready(function() {

	var myTable;
	var data;
	var selectedData;
	
	fetchTableData("http://localhost:8080/Select");
	
	var insertPlantElements = 
	
	[         					"#MARKETInsertInput","#BRANDInsertInput","#MODEL_YEARInsertInput","#BODY_MODELInsertInput",
	                            "#TRANS_SCInsertInput","#ENG_SCInsertInput","#DEALERInsertInput","#ZONEInsertInput",
	                            "#MISInsertInput","#ELIG_FLAGInsertInput","#STATUSInsertInput","#MESSAGEInsertInput",
								"#EFFECTIVE_START_DATEInsertInput","#EFFECTIVE_END_DATEInsertInput",
								"#LOP1_2InsertInput","#LOP3_4InsertInput","#LOP5_6InsertInput","#LOP7_8InsertInput"
    ];
	
	var updatePlantElements = 
	
	[							"#MARKETupdateOld","#BRANDupdateOld","#MODEL_YEARupdateOld","#BODY_MODELupdateOld",
								"#ENG_SCupdateOld","#TRANS_SCupdateOld","#DEALERupdateOld","#ZONEupdateOld",
								"#MISupdateOld","#ELIG_FLAGupdateOld","#STATUSupdateOld","#MESSAGEupdateOld",
								"#EFFECTIVE_START_DATEupdateOld","#EFFECTIVE_END_DATEupdateOld",
								"#LOP1_2updateOld","#LOP3_4updateOld","#LOP5_6updateOld","#LOP7_8updateOld"
    ];
	
	
	var copyPlantElements = 
	
	[						"#MARKETupdateNew","#BRANDupdateNew","#MODEL_YEARupdateNew","#BODY_MODELupdateNew", 
							"#ENG_SCupdateNew","#TRANS_SCupdateNew","#DEALERupdateNew","#ZONEupdateNew", 
							"#MISupdateNew","#ELIG_FLAGupdateNew","#STATUSupdateNew","#MESSAGEupdateNew",
							"#EFFECTIVE_START_DATEupdateNew","#EFFECTIVE_END_DATEupdateNew",
							"#LOP1_2updateNew","#LOP3_4updateNew","#LOP5_6updateNew","#LOP7_8updateNew"
	];
	
	var deletePlantElements = 
	
	[						"#MARKETdeleteOld","#BRANDdeleteOld", "#MODEL_YEARdeleteOld", "#BODY_MODELdeleteOld",
							"#ENG_SCdeleteOld","#TRANS_SCdeleteOld","#DEALERdeleteOld","#ZONEdeleteOld",
							"#MISdeleteOld","#ELIG_FLAGdeleteOld","#STATUSdeleteOld","#MESSAGEdeleteOld",
							"#EFFECTIVE_START_DATEdeleteOld","#EFFECTIVE_END_DATEdeleteOld",
							"#LOP1_2deleteOld","#LOP3_4deleteOld","#LOP5_6deleteOld","#LOP7_8deleteOld"
	];
	
	var plantElements = ["market","brand","model_YEAR" ,"body_MODEL","eng_SC","trans_SC","dealer","zone1","mis","elig_FLAG","status","message","effective_START_DATE","effective_END_DATE","lop1_2","lop3_4","lop5_6","lop7_8"];
	
	

	// var PARM = 'parm';
	// $('#plantSelect').on('change',function() {
	//	dropSelection = $(this).val();
    //  if (dropSelection == PARM)
	//	{
	//	fetchTableData("http://localhost:8080/Select");
	//	}
	//});
	
	//Change data on tables
	$('#plantInsertBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var insertData = getInputData(plantElements, insertPlantElements);
			postData(insertData,"http://localhost:8080/Insert","POST");
		}
	});

	//Show / hide data update input fields
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
			$('#insertPlantDesc').show();
	});

	$('#plantUpdateBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var updateData = [];
			updateData.push(getInputData(plantElements, updatePlantElements));
			updateData.push(getInputData(plantElements, copyPlantElements));
			postData(updateData, "http://localhost:8080/Update", "POST" );
		}
	});
	
	$('#updateBtn').on('click', function() {
	   $('.toggle-div').hide();
			$('#updatePlantDesc').show();
	});

	$('.copy-btn').on('click', function() {
		copyInputVals(updatePlantElements, copyPlantElements);
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
			$('#deletePlantDesc').show();
	});
	
	$('#plantDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = getInputData(plantElements, deletePlantElements);
			postData(deleteData, "http://localhost:8080/Delete", "DELETE");
		}
	});
	
	function fetchTableData(url){
        dataType: 'json',
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable();
			}
		});
	}
	
	function postData(myData,url,method) {
		$.ajax({
			data: JSON.stringify(myData),
			url: url,
			method: method,
			contentType: "application/json",
			success: function(result) {
				data = result;
				if("isNotDuplicate" !== data[0].exceptionMsg){
					document.getElementById("alertMsg").style.display= "block";
					document.getElementById("alertMsg").innerHTML = data[0].exceptionMsg;
				}
				emptyTable();
				updateTable();
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
	function updateTable() {
			myTable = $('#ParmTable').DataTable({
			  "pageLength": 100,
			  "aaSorting": [[ 1, "desc" ]],
				data: data,
				columns: [
				//	 {title: 'TI1MESTAMP',													data: 'updateTimestamp'},
				     {title: 'Effective<br>Start Date<span class = "colorclass">*</span>',		data: 'effective_START_DATE'},
				     {title: 'Effective<br>End Date<span class = "colorclass">*</span>'  ,		data: 'effective_END_DATE'},
					 {title: 'MKT<span class = "colorclass">*</span><br>',						data: 'market'},
				     {title: 'Brand<span class = "colorclass">*</span><br>',					data: 'brand'},
				     {title: 'Body<br>Model<span class = "colorclass">*</span>',				data: 'body_MODEL'},
				     {title: 'Model<br>Year<span class = "colorclass">*</span>', 				data: 'model_YEAR'},
				     {title: 'Engine<br>Sales Code<span class = "colorclass">*</span>',		data: 'eng_SC'},
				     {title: 'Transmission<br>Sales Code<span class = "colorclass">*</span>',	data: 'trans_SC'},
				     {title: 'Dealer<br>Zone<span class = "colorclass">*</span>',				data: 'zone1'},
				     {title: 'Dealer<br>Code<span class = "colorclass">*</span>',				data: 'dealer'},
				     {title: 'LOP<br>Function Group<span class = "colorclass">*</span>',		data: 'lop1_2'},
				     {title: 'LOP<br>Component Group<span class = "colorclass">*</span>',		data: 'lop3_4'},
				     {title: 'LOP<br>Component<span class = "colorclass">*</span>',			data: 'lop5_6'},
				     {title: 'LOP<br>Code<span class = "colorclass">*</span>',					data: 'lop7_8'},
				     {title: 'MIS<span class = "colorclass">*</span><br>',						data: 'mis'},
				     {title: 'DIDI Eligibility<br>Flag',										data: 'elig_FLAG'},
				 //  {title: 'Status',														data: 'status'},
				   	 {title: 'DIDI Eligibility<br>Message',									data: 'message'},
				  	
				],
			});
		}
		
		//Row selection
		$('#ParmTable tbody').on( 'click', 'tr', function () {
	        clearInputVals(insertPlantElements);
			clearInputVals(updatePlantElements);
			clearInputVals(deletePlantElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	          
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            setInputVals(selectedData, plantElements, updatePlantElements);
	            setInputVals(selectedData, plantElements, deletePlantElements);
	            setInputVals(selectedData, plantElements, insertPlantElements);
	        }
	    } );
	    
	    
	    
	    
			
	function emptyTable() {
		clearInputVals(deletePlantElements);
		clearInputVals(updatePlantElements);
		clearInputVals(copyPlantElements);
		clearInputVals(insertPlantElements);
		selectedData = {};
		
		if (myTable != null)
		{
			$('#ParmTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}	
	
});