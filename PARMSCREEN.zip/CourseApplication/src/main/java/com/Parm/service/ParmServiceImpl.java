package com.Parm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.Parm.dao.ParmDao;
import com.Parm.dao.UserDAO;
import com.Parm.entity.Parm;
import com.Parm.entity.UserEntity;
import com.Parm.dto.*;

@Service
public class ParmServiceImpl implements ParmService {

	@Autowired
	ParmDao parmDao;

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	JdbcTemplate jdbcTemplate1;

	@Autowired
	UserDAO userDAO;
	
	@Override
	public String getUser(String userId) {
		boolean res = userDAO.existsById(userId);
		if(res==true) {
			Optional<UserEntity> list = userDAO.findById(userId);
			return (list.get().getUSER_ACCESS());
		}else {
			return "";
		}
	}
	
	
	@Override
	public List<Parm> getAllParms(String exception) {

		//String sqlQuery = "select * from parm where status = 'A' order by instant DESC"; sorting based on timestamp if this is the first column timestamp
		String sqlQuery = "select * from parm where status = 'A'";
		List<Parm> parmList = jdbcTemplate.query(sqlQuery, new ParmDTO("", exception));
		return parmList;

	}

	@Override
	public List<Parm> InsertParms(Parm parm) {

		String MARKET = parm.getMARKET().toUpperCase();
		String BRAND = parm.getBRAND().toUpperCase();
		String YEAR = parm.getMODEL_YEAR().toUpperCase();
		String BODY_MODEL = parm.getBODY_MODEL().toUpperCase();
		String ENG_SC = parm.getENG_SC().toUpperCase();
		String TRANS_SC = parm.getTRANS_SC().toUpperCase();
		String Dealer = parm.getDEALER().toUpperCase();
		String ZONE1 = parm.getZONE1().toUpperCase();
		String MIS = parm.getMIS();
		String FLAG = parm.getELIG_FLAG().toUpperCase();
		String STATUS = "A";
		String ESD = parm.getEFFECTIVE_START_DATE();
		String EED = parm.getEFFECTIVE_END_DATE();
		String MSG = parm.getMESSAGE().toUpperCase();
		String LOP1_2 = parm.getLOP1_2().toUpperCase();
		String LOP3_4 = parm.getLOP3_4().toUpperCase();
		String LOP5_6 = parm.getLOP5_6().toUpperCase();
		String LOP7_8 = parm.getLOP7_8().toUpperCase();
	//	Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());	
//		ESD = ConvertDateIntoFormatMM_DD_YYYY(ESD);
//		System.out.println(ESD);
		
		if (MARKET == null) {
			MARKET = "";
		}
		if (BRAND == null) {
			BRAND = "";
		}
		if (YEAR == null) {
			YEAR = "";
		}
		if (BODY_MODEL == null) {
			BODY_MODEL = "";
		}
		if (ENG_SC == null) {
			ENG_SC = "";
		}
		if (TRANS_SC == null) {
			TRANS_SC = "";
		}
		if (Dealer == null) {
			Dealer = "";
		}
		if (ZONE1 == null) {
			ZONE1 = "";
		}
		if (MIS == null) {
			MIS = "";
		}
		if (FLAG == null) {
			FLAG = "";
		}
		if (MSG == null) {
			MSG = "";
		}
		if (ESD == null) {
			ESD = "";
		}
		if (EED == null) {
			EED = "";
		}
		if (LOP1_2 == null) {
			LOP1_2 = "";
		}
		if (LOP3_4 == null) {
			LOP3_4 = "";
		}
		if (LOP5_6 == null) {
			LOP5_6 = "";
		}
		if (LOP7_8 == null) {
			LOP7_8 = "";
		}

		
		
//		String sqlQuery = "insert into parm (MARKET,BRAND,MODEL_YEAR,BODY_MODEL,ENG_SC,TRANS_SC,DEALER,ZONE1, MIS,ELIG_FLAG,STATUS,MESSAGE,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,LOP1_2,LOP3_4,LOP5_6,LOP7_8,instant)"
//				+ "VALUES('" + MARKET + "','" + BRAND + "','" + YEAR + "','" + BODY_MODEL + "','" + ENG_SC + "','"
//				+ TRANS_SC + "','" + Dealer + "','" + ZONE1 + "','" + MIS + "','" + FLAG + "','" + STATUS + "','" + MSG
//				+ "','" + ESD + "','" + EED + "','" + LOP1_2 + "','" + LOP3_4 + "','" + LOP5_6 + "','" + LOP7_8 + "','"+currentTimestamp+"')";
//		
//		
		String sqlQuery = "insert into parm (MARKET,BRAND,MODEL_YEAR,BODY_MODEL,ENG_SC,TRANS_SC,DEALER,ZONE1, MIS,ELIG_FLAG,STATUS,MESSAGE,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,LOP1_2,LOP3_4,LOP5_6,LOP7_8)"
				+ "VALUES('" + MARKET + "','" + BRAND + "','" + YEAR + "','" + BODY_MODEL + "','" + ENG_SC + "','"
				+ TRANS_SC + "','" + Dealer + "','" + ZONE1 + "','" + MIS + "','" + FLAG + "','" + STATUS + "','" + MSG
				+ "','" + ESD + "','" + EED + "','" + LOP1_2 + "','" + LOP3_4 + "','" + LOP5_6 + "','" + LOP7_8 + "')";
		
		
		
		String excMsg = null;
		try {
			jdbcTemplate1.execute(sqlQuery);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			excMsg = e.getMessage();
		}
		return getAllParms(excMsg);
	}

	@Override
	public List<Parm> UpdateParms(List<Parm> parm) {

		Parm parm1 = parm.get(0);// previous records update with status U
		Parm parm2 = parm.get(1);// updated records insert with new Records
		int count=0;
		
		String MARKET1 = parm2.getMARKET().toUpperCase();
		String BRAND1= parm2.getBRAND().toUpperCase();
		String YEAR1 = parm2.getMODEL_YEAR().toUpperCase();
		String BODY_MODEL1 = parm2.getBODY_MODEL().toUpperCase();
		String ENG_SC1 = parm2.getENG_SC().toUpperCase();
		String TRANS_SC1 = parm2.getTRANS_SC().toUpperCase();
		String Dealer1 = parm2.getDEALER().toUpperCase();
		String ZONE11 = parm2.getZONE1().toUpperCase();
		String MIS1 = parm2.getMIS().toUpperCase();
		String FLAG1 = parm2.getELIG_FLAG().toUpperCase();
		String STATUS1 = "A";
		String MSG1 = parm2.getMESSAGE().toUpperCase();
		String ESD1 = parm2.getEFFECTIVE_START_DATE();
		String EED1 = parm2.getEFFECTIVE_END_DATE();
		String LOP1_21 = parm2.getLOP1_2().toUpperCase();
		String LOP3_41 = parm2.getLOP3_4().toUpperCase();
		String LOP5_61 = parm2.getLOP5_6().toUpperCase();
		String LOP7_81 = parm2.getLOP7_8().toUpperCase();
		
		String excMsg = null;

		if (MARKET1 == null) {
			MARKET1 = "";
		}
		if (BRAND1 == null) {
			BRAND1 = "";
		}
		if (YEAR1 == null) {
			YEAR1 = "";
		}
		if (BODY_MODEL1 == null) {
			BODY_MODEL1 = "";
		}
		if (ENG_SC1 == null) {
			ENG_SC1= "";
		}
		if (TRANS_SC1 == null) {
			TRANS_SC1 = "";
		}
		if (Dealer1 == null) {
			Dealer1 = "";
		}
		if (ZONE11 == null) {
			ZONE11 = "";
		}
		if (MIS1 == null) {
			MIS1 = "";
		}
		if (FLAG1 == null) {
			FLAG1 = "";
		}
		if (MSG1 == null) {
			MSG1 = "";
		}
		if (ESD1 == null) {
			ESD1 = "";
		}
		if (EED1 == null) {
			EED1 = "";
		}
		if (LOP1_21 == null) {
			LOP1_21 = "";
		}
		if (LOP3_41 == null) {
			LOP3_41 = "";
		}
		if (LOP5_61 == null) {
			LOP5_61 = "";
		}
		if (LOP7_81 == null) {
			LOP7_81 = "";
		}

		
		String sqlQuery2 = "insert into parm (MARKET,BRAND,MODEL_YEAR,BODY_MODEL,ENG_SC,TRANS_SC,DEALER,ZONE1, MIS,ELIG_FLAG,STATUS,MESSAGE,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,LOP1_2,LOP3_4,LOP5_6,LOP7_8)"
				+ "VALUES('" + MARKET1 + "','" + BRAND1 + "','" + YEAR1 + "','" + BODY_MODEL1 + "','" + ENG_SC1 + "','"
				+ TRANS_SC1 + "','" + Dealer1 + "','" + ZONE11 + "','" + MIS1 + "','" + FLAG1 + "','" + STATUS1 + "','" + MSG1
				+ "','" + ESD1 + "','" + EED1 + "','" + LOP1_21 + "','" + LOP3_41 + "','" + LOP5_61 + "','" + LOP7_81 +"')";
		try {
			jdbcTemplate1.execute(sqlQuery2);
			count++;
		} catch (Exception e) {
			excMsg = e.getMessage();
		}
		
		String MARKET  	 	= parm1.getMARKET().toUpperCase();
		String BRAND 		= parm1.getBRAND().toUpperCase();
		String YEAR    	 	= parm1.getMODEL_YEAR().toUpperCase();
		String BODY_MODEL	= parm1.getBODY_MODEL().toUpperCase();
		String ENG_SC 		= parm1.getENG_SC().toUpperCase();
		String TRANS_SC 	= parm1.getTRANS_SC().toUpperCase();
		String Dealer 		= parm1.getDEALER().toUpperCase();
		String ZONE1 		= parm1.getZONE1().toUpperCase();
		String MIS 			= parm1.getMIS().toUpperCase();
		String LOP1_2 		= parm1.getLOP1_2().toUpperCase();
		String LOP3_4 		= parm1.getLOP3_4().toUpperCase();
		String LOP5_6 		= parm1.getLOP5_6().toUpperCase();
		String LOP7_8 		= parm1.getLOP7_8().toUpperCase();
		
		
		//String sqlQuery1 = "update parm set status = 'U' where brand = '" + ids + "'";
		String sqlQyery1 = "update parm set status = 'U' where brand='"+BRAND+"' AND market ='"+MARKET+"' AND model_year ='"+YEAR+"' AND body_model ='"+BODY_MODEL+"' AND eng_sc ='"+ENG_SC+"' AND trans_sc ='"+TRANS_SC+"' AND dealer ='"+Dealer+"' AND zone1 ='"+ZONE1+"' AND mis ='"+MIS+"'AND  lop1_2 ='"+LOP1_2+"' AND lop3_4 ='"+LOP3_4+"' AND lop5_6 ='"+LOP5_6+"' AND lop7_8 ='"+LOP7_8+"'";
		if(count>0) {
		try {
			jdbcTemplate1.update(sqlQyery1);
		} catch (Exception e) {
			excMsg = e.getMessage();
		}
		}
		count=0;
		return getAllParms(excMsg);

	}

	@Override
	public List<Parm> DeleteParms(Parm parm) {

		String MARKET  	 	= parm.getMARKET();
		String BRAND 		= parm.getBRAND();
		String YEAR    	 	= parm.getMODEL_YEAR();
		String BODY_MODEL	= parm.getBODY_MODEL();
		String ENG_SC 		= parm.getENG_SC();
		String TRANS_SC 	= parm.getTRANS_SC();
		String Dealer 		= parm.getDEALER();
		String ZONE1 		= parm.getZONE1();
		String MIS 			= parm.getMIS();
		String LOP1_2 		= parm.getLOP1_2();
		String LOP3_4 		= parm.getLOP3_4();
		String LOP5_6 		= parm.getLOP5_6();
		String LOP7_8 		= parm.getLOP7_8();
		
		//String sqlQuery = "update parm set status = 'D' where brand='"+BRAND+"'AND  market ='"+MARKET+"'&& model_year = '"+YEAR+"'";
		String sqlQyery1 = "update parm set status = 'D' where brand='"+BRAND+"' AND market ='"+MARKET+"' AND model_year ='"+YEAR+"' AND body_model ='"+BODY_MODEL+"' AND eng_sc ='"+ENG_SC+"' AND trans_sc ='"+TRANS_SC+"' AND dealer ='"+Dealer+"' AND zone1 ='"+ZONE1+"' AND mis ='"+MIS+"'AND  lop1_2 ='"+LOP1_2+"' AND lop3_4 ='"+LOP3_4+"' AND lop5_6 ='"+LOP5_6+"' AND lop7_8 ='"+LOP7_8+"'";
		
		jdbcTemplate1.update(sqlQyery1);

		return getAllParms(null);
	}
	
	public String ConvertDateIntoFormatMM_DD_YYYY(String date1){
		//  01/01/1999---MM/DD/YYYY
		//YYYY-MM-DD
		System.out.println(date1);
		String str1yyyy = date1.substring(0,4);
		String str2mm = date1.substring(5,7);
		String str3dd = date1.substring(8,10);
		
		String ansmmddyy = str2mm.concat("-").concat(str3dd).concat("-").concat(str1yyyy);
		System.out.println(ansmmddyy);
		return ansmmddyy;
		
	}

	
}
