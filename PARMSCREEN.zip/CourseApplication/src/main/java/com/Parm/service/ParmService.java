package com.Parm.service;

import java.util.List;
import com.Parm.entity.Parm;

public interface ParmService {
	
	public String getUser(String userId);

	public List<Parm> getAllParms(String exception);

	public List<Parm> InsertParms(Parm parm);

	public List<Parm> UpdateParms(List<Parm> parm);

	public List<Parm>  DeleteParms(Parm parm);

}
