package com.Parm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.Parm.entity.UserEntity;

public interface UserDAO extends JpaRepository<UserEntity, String>,CrudRepository<UserEntity, String> {

}
