package com.Parm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.Parm.entity.Parm;

public interface ParmDao extends JpaRepository<Parm, String>,CrudRepository<Parm, String>{

}
