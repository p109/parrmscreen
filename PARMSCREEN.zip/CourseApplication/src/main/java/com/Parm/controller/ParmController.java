package com.Parm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.Parm.entity.Parm;
import com.Parm.service.ParmService;

@Controller
public class ParmController {

	@Autowired
	ParmService parmservice;
	
	
	@RequestMapping("/")
	public String getUserAuthorization() {
		
		String userid = "T0088PY";   ////////here we need to get the user id from jwt
		String ans  =  parmservice.getUser(userid);
		ans=ans.trim();
		if(ans.isEmpty()) {
			return "User";
		}
        return "redirect:/Parm";
	}
	
	
	@RequestMapping("/Parm")
	public String Frontend() {
		return "Parm";
	}
	
	@RequestMapping("/Select")
	@ResponseBody
	public List<Parm> getAllParms() {
		return parmservice.getAllParms(null);
	}

	@PostMapping(value = "/Insert")
	@ResponseBody
	public List<Parm> InsertParms(@RequestBody Parm parm ){
		List<Parm> parm1 = parmservice.InsertParms(parm);
		return parm1;
	}

	@PostMapping(value = "/Update")
	@ResponseBody
	public List<Parm> UpdateParms(@RequestBody List<Parm> parm) {
		 return parmservice.UpdateParms(parm);
	}

	@DeleteMapping(value = "/Delete")
	@ResponseBody
	public List<Parm> DeleteParms(@RequestBody Parm parm) {
		return parmservice.DeleteParms(parm);
	}
}
