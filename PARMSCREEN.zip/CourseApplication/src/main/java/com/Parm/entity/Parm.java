package com.Parm.entity;

import javax.persistence.*;

@Entity
public class Parm {

	@Id
	@Column
	String MARKET;
	@Column
	String BRAND;
	@Column
	String MODEL_YEAR;
	@Column
	String BODY_MODEL;
	@Column
	String ENG_SC;
	@Column
	String TRANS_SC;
	@Column
	String DEALER;
	@Column
	String ZONE1;
	@Column
	String MIS;
	@Column
	String ELIG_FLAG;
	@Column
	String STATUS;
	@Column
	String MESSAGE;
	@Column
	String EFFECTIVE_START_DATE;
	@Column
	String EFFECTIVE_END_DATE;
	@Column
	String LOP1_2;
	@Column
	String LOP3_4;
	@Column
	String LOP5_6;
	@Column
	String LOP7_8;
//	@Transient
//	Timestamp updateTimestamp;
	@Transient
	String exceptionMsg;
	public Parm() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Parm(String mARKET, String bRAND, String mODEL_YEAR, String bODY_MODEL, String eNG_SC, String tRANS_SC,
			String dEALER, String zONE1, String mIS, String eLIG_FLAG, String sTATUS, String mESSAGE,
			String eFFECTIVE_START_DATE, String eFFECTIVE_END_DATE, String lOP1_2, String lOP3_4, String lOP5_6,
			String lOP7_8, String exceptionMsg) {
		super();
		MARKET = mARKET;
		BRAND = bRAND;
		MODEL_YEAR = mODEL_YEAR;
		BODY_MODEL = bODY_MODEL;
		ENG_SC = eNG_SC;
		TRANS_SC = tRANS_SC;
		DEALER = dEALER;
		ZONE1 = zONE1;
		MIS = mIS;
		ELIG_FLAG = eLIG_FLAG;
		STATUS = sTATUS;
		MESSAGE = mESSAGE;
		EFFECTIVE_START_DATE = eFFECTIVE_START_DATE;
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
		LOP1_2 = lOP1_2;
		LOP3_4 = lOP3_4;
		LOP5_6 = lOP5_6;
		LOP7_8 = lOP7_8;
		this.exceptionMsg = exceptionMsg;
	}
	public String getMARKET() {
		return MARKET;
	}
	public void setMARKET(String mARKET) {
		MARKET = mARKET;
	}
	public String getBRAND() {
		return BRAND;
	}
	public void setBRAND(String bRAND) {
		BRAND = bRAND;
	}
	public String getMODEL_YEAR() {
		return MODEL_YEAR;
	}
	public void setMODEL_YEAR(String mODEL_YEAR) {
		MODEL_YEAR = mODEL_YEAR;
	}
	public String getBODY_MODEL() {
		return BODY_MODEL;
	}
	public void setBODY_MODEL(String bODY_MODEL) {
		BODY_MODEL = bODY_MODEL;
	}
	public String getENG_SC() {
		return ENG_SC;
	}
	public void setENG_SC(String eNG_SC) {
		ENG_SC = eNG_SC;
	}
	public String getTRANS_SC() {
		return TRANS_SC;
	}
	public void setTRANS_SC(String tRANS_SC) {
		TRANS_SC = tRANS_SC;
	}
	public String getDEALER() {
		return DEALER;
	}
	public void setDEALER(String dEALER) {
		DEALER = dEALER;
	}
	public String getZONE1() {
		return ZONE1;
	}
	public void setZONE1(String zONE1) {
		ZONE1 = zONE1;
	}
	public String getMIS() {
		return MIS;
	}
	public void setMIS(String mIS) {
		MIS = mIS;
	}
	public String getELIG_FLAG() {
		return ELIG_FLAG;
	}
	public void setELIG_FLAG(String eLIG_FLAG) {
		ELIG_FLAG = eLIG_FLAG;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getMESSAGE() {
		return MESSAGE;
	}
	public void setMESSAGE(String mESSAGE) {
		MESSAGE = mESSAGE;
	}
	public String getEFFECTIVE_START_DATE() {
		return EFFECTIVE_START_DATE;
	}
	public void setEFFECTIVE_START_DATE(String eFFECTIVE_START_DATE) {
		EFFECTIVE_START_DATE = eFFECTIVE_START_DATE;
	}
	public String getEFFECTIVE_END_DATE() {
		return EFFECTIVE_END_DATE;
	}
	public void setEFFECTIVE_END_DATE(String eFFECTIVE_END_DATE) {
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
	}
	public String getLOP1_2() {
		return LOP1_2;
	}
	public void setLOP1_2(String lOP1_2) {
		LOP1_2 = lOP1_2;
	}
	public String getLOP3_4() {
		return LOP3_4;
	}
	public void setLOP3_4(String lOP3_4) {
		LOP3_4 = lOP3_4;
	}
	public String getLOP5_6() {
		return LOP5_6;
	}
	public void setLOP5_6(String lOP5_6) {
		LOP5_6 = lOP5_6;
	}
	public String getLOP7_8() {
		return LOP7_8;
	}
	public void setLOP7_8(String lOP7_8) {
		LOP7_8 = lOP7_8;
	}
	public String getExceptionMsg() {
		return exceptionMsg;
	}
	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}
	@Override
	public String toString() {
		return "Parm [MARKET=" + MARKET + ", BRAND=" + BRAND + ", MODEL_YEAR=" + MODEL_YEAR + ", BODY_MODEL="
				+ BODY_MODEL + ", ENG_SC=" + ENG_SC + ", TRANS_SC=" + TRANS_SC + ", DEALER=" + DEALER + ", ZONE1="
				+ ZONE1 + ", MIS=" + MIS + ", ELIG_FLAG=" + ELIG_FLAG + ", STATUS=" + STATUS + ", MESSAGE=" + MESSAGE
				+ ", EFFECTIVE_START_DATE=" + EFFECTIVE_START_DATE + ", EFFECTIVE_END_DATE=" + EFFECTIVE_END_DATE
				+ ", LOP1_2=" + LOP1_2 + ", LOP3_4=" + LOP3_4 + ", LOP5_6=" + LOP5_6 + ", LOP7_8=" + LOP7_8
				+ ", exceptionMsg=" + exceptionMsg + "]";
	}
	
	
	
}
