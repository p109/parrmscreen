package com.Parm.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;
import com.Parm.entity.Parm;

public class ParmDTO  implements RowMapper<Parm>{

	
	String type="";
	String exception=null;
	public ParmDTO(String type,String Exception) {
		super();
		this.type = type;
		this.exception = Exception;
	}
	public ParmDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public Parm mapRow(ResultSet rs, int rowNum) throws SQLException {
		Parm parm = new Parm();
		//Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		parm.setMARKET(rs.getString("MARKET"));
		parm.setBRAND(rs.getString("BRAND"));
		parm.setMODEL_YEAR(rs.getString("MODEL_YEAR"));
		parm.setBODY_MODEL(rs.getString("BODY_MODEL"));
		parm.setENG_SC(rs.getString("ENG_SC"));
		parm.setTRANS_SC(rs.getString("TRANS_SC"));
		parm.setDEALER(rs.getString("DEALER"));
		parm.setZONE1(rs.getString("ZONE1"));
		parm.setMIS(rs.getString("MIS"));
		parm.setELIG_FLAG(rs.getString("ELIG_FLAG"));
		parm.setSTATUS(rs.getString("STATUS"));
		parm.setMESSAGE(rs.getString("MESSAGE"));
		parm.setEFFECTIVE_START_DATE(rs.getString("EFFECTIVE_START_DATE"));
		parm.setEFFECTIVE_END_DATE(rs.getString("EFFECTIVE_END_DATE"));
		parm.setLOP1_2(rs.getString("LOP1_2"));
		parm.setLOP3_4(rs.getString("LOP3_4"));
		parm.setLOP5_6(rs.getString("LOP5_6"));
		parm.setLOP7_8(rs.getString("LOP7_8"));
		//parm.setUpdateTimestamp(currentTimestamp);
		parm.setExceptionMsg(this.exception!=null?"Do Not Entered Duplicates Entry Or Please Enter Correct Values":"isNotDuplicate");
		return parm;
	}

}
